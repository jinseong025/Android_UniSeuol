package com.nugu.uniseoul.data;

public class BusData {
    private String string;
    private int viewType;

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }
}
