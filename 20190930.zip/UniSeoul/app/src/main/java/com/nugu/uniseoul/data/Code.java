package com.nugu.uniseoul.data;

public class Code {
    public class ViewType{
        public static final int NAME = 0;
        public static final int DIRECTION = 1;
    }
}
